package co.edu.uniquindio.programacion2.hotel.service;

public interface IConsumible {

    void consumir();
}
