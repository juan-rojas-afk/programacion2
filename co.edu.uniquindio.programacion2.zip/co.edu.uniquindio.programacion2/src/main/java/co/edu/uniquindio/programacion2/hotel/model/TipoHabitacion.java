package co.edu.uniquindio.programacion2.hotel.model;

public enum TipoHabitacion {
    DOUBLE,
    SUITE,
    SIMPLE
}
